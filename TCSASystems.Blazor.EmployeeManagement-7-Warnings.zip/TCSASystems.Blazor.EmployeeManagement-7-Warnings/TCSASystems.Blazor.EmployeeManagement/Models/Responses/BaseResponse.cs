﻿namespace TCSASystems.Blazor.EmployeeManagement.Models.Responses;

public class BaseResponse
{
    public int StatusCode { get; set; }
    public string Message { get; set; }
}
